```html
#nav li {
  display: inline;
  list-style-type: none;
}
```

Why does this work?