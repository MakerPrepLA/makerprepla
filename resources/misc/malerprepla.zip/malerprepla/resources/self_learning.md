# Self-Guided Learning

## JavaScript Fundamentals

1. [Eloquent JavaScript](http://eloquentjavascript.net/)
2. [CodeAcademy](https://www.codecademy.com/learn) - Any tracks related to HTML, CSS, and JavaScript. The new [command line](https://www.codecademy.com/en/courses/learn-the-command-line) course is great as well.
3. [LearnRx](https://github.com/jhusain/learnrx)
4. [Higher-Order Functions](https://www.youtube.com/watch?v=BMUiFMZr7vk)
5. [Codewars](http://www.codewars.com/)
